package com.example.myapplication.sp33;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SP33MainActivity extends AppCompatActivity {
    private ListView listView;
    private List<SP33Product> list=new ArrayList<>();
    private SP33Adapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp33_main);
        listView=findViewById(R.id.sp33Listview);
        adapter=new SP33Adapter(this,list);
        listView.setAdapter(adapter);
        new FetchDataTask().execute();
    }
    private class FetchDataTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            //box chua du lieu
            StringBuilder response=new StringBuilder();
            try {
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");
                //mo ket noi
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //chon phuong thuc doc du lieu
                connection.setRequestMethod("GET");
                //Tao bo dem doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc tung dong
                String line="";
                while ((line=reader.readLine())!=null){//doc tu dau den cuoi
                    response.append(line);//dua cac dong doc duoc vao response
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //tra ket qua ve cho client
        @Override
        protected void onPostExecute(String s) {

            if(s!=null && !s.isEmpty()){
                try {
                    //chuyen ket qua ve json: co doi tuong product
                    JSONObject json=new JSONObject(s);
                    //lay ve mang cac doi tuong
                    JSONArray pArray=json.getJSONArray("products");
                    //lay ve cac doi tuong con thong qua vong lap
                    for(int i=0;i<pArray.length();i++){
                        JSONObject pObj=pArray.getJSONObject(i);//lay ve doi tuong i
                        //lay tung truong
                        String searchImage=pObj.getString("search_image");
                        String styleid=pObj.getString("styleid");
                        String brands=pObj.getString("brands_filter_facet");
                        String price=pObj.getString("price");
                        String pInfo=pObj.getString("product_additional_info");
                        //tao doi tuong tu cac truong tren
                        SP33Product product=new SP33Product(searchImage,styleid,brands,price,pInfo);
                        //dua product vao list
                        list.add(product);
                    }
                    adapter.notifyDataSetChanged();//cap nhat du lieu vao adapter
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }

            }
        }
    }
}