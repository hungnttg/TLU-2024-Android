package com.example.myapplication.tuan6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

public class Tuan6DetailActivity extends AppCompatActivity {
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuan6_detail);
        //nhan du lieu tu listproduct chuyen sang
        Intent intent=getIntent();
        Tuan6Product product=intent.getParcelableExtra("PRODUCT");
        //anh xa cac thanh phan len giao dienj
        ImageView imgPro=findViewById(R.id.tuan6detailImg);
        TextView tvStyleIdPro=findViewById(R.id.tuan6detailTvStyleId);
        TextView tvPricePro=findViewById(R.id.tuan6detailTvPrice);
        TextView tvInfoPro = findViewById(R.id.tuan6detailTvAddInfo);
        TextView tvBrandPro=findViewById(R.id.tuan6detailTvBrand);
        //hien thi thong tin chi tiet cua san pham
        if(product!=null){
            //hien thi anh
            Picasso.get().load(product.getSearchImage())
                    .into(imgPro);
            //hien thi text
            tvInfoPro.setText("Info: "+product.getAdditionalInfo());
            tvBrandPro.setText("Brand: "+product.getBrand());
            tvPricePro.setText("Price: "+product.getPrice());
            tvStyleIdPro.setText("StyleID: "+product.getStyleId());
        }
    }
}