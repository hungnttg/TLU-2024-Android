package com.example.myapplication.t61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

public class DetailProductActivity extends AppCompatActivity {
    private CartManager cartManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_product);
        // Lấy một thể hiện duy nhất của CartManager
        cartManager = CartManager.getInstance();
        // Nhận dữ liệu sản phẩm từ intent
        Intent intent = getIntent();
        Product product = intent.getParcelableExtra("PRODUCT");

        // Ánh xạ các thành phần giao diện
        ImageView imageViewProduct = findViewById(R.id.imageViewProduct);
        TextView textViewStyleId = findViewById(R.id.textViewStyleId);
        TextView textViewBrand = findViewById(R.id.textViewBrand);
        TextView textViewPrice = findViewById(R.id.textViewPrice);
        TextView textViewAdditionalInfo
                = findViewById(R.id.textViewAdditionalInfo);
        Button addToCart = findViewById(R.id.buttonAddToCart);
        addToCart.setOnClickListener(v-> addToCartClicked());

        // Hiển thị thông tin chi tiết của sản phẩm
        if (product != null) {
            // Hiển thị ảnh sản phẩm (nếu có)
            // Đây là ví dụ, bạn cần sử dụng thư viện Picasso hoặc Glide để tải ảnh từ URL
            Picasso.get().load(product.getSearchImage())
                    .into(imageViewProduct);
            // Glide.with(this).load(product.getSearchImage())
            // .into(imageViewProduct);

            // Hiển thị thông tin chi tiết của sản phẩm
            textViewStyleId.setText("Style ID: " + product.getStyleId());
            textViewBrand.setText("Brand: " + product.getBrand());
            textViewPrice.setText("Price: " + product.getPrice());
            textViewAdditionalInfo.setText("Additional Info: "
                    + product.getAdditionalInfo());
        }


    }
    //--create add to cart----
    private void addToCartClicked() {
        Intent intent = getIntent();
        Product product = intent.getParcelableExtra("PRODUCT");

        if (product != null) {
            // Thêm sản phẩm vào giỏ hàng
            cartManager.addProductToCart(product);
           // Toast.makeText(this, "Product added to cart", Toast.LENGTH_SHORT).show();

            // Mở CartActivity
            Intent cartIntent = new Intent(this, CartActivity.class);
            startActivity(cartIntent);
        }
    }
    //---end----
}