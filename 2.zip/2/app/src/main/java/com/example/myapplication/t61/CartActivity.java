package com.example.myapplication.t61;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.List;

public class CartActivity extends AppCompatActivity {
    private ListView listViewCart;
    private CartAdapter cartAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        // Ánh xạ ListView và thiết lập adapter
        listViewCart = findViewById(R.id.listViewCart);
        // Khởi tạo danh sách giỏ hàng và adapter
        // Lấy một thể hiện duy nhất của CartManager
        CartManager cartManager = CartManager.getInstance();
        List<Product> cartItems = cartManager.getCartItems();

        // Khởi tạo adapter và thiết lập cho ListView
        cartAdapter = new CartAdapter(this, cartItems);
        listViewCart = findViewById(R.id.listViewCart);
        listViewCart.setAdapter(cartAdapter);

    }
}