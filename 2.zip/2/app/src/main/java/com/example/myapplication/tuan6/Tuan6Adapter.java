package com.example.myapplication.tuan6;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Tuan6Adapter extends BaseAdapter {
    private Context mContext;
    private List<Tuan6Product> mList;

    public Tuan6Adapter(Context mContext, List<Tuan6Product> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //create layout
    //set data
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Tuan6ViewHolder holder;
        if(convertView==null)//not exist view
        {
            //create blank layout
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.item_view_tuan6,parent,false);
            //refer components
            holder=new Tuan6ViewHolder();
            holder.searchImage=convertView.findViewById(R.id.tuan6_itemView_image);
            holder.tvAddictionalInfo=convertView.findViewById(R.id.tuan6_itemView_addictionalInfo);
            holder.tvBrand=convertView.findViewById(R.id.tuan6_itemView_brand);
            holder.tvPrice=convertView.findViewById(R.id.tuan6_itemView_price);
            holder.tvStyleId=convertView.findViewById(R.id.tuan6_itemView_styleid);
            //create a new template for later
            convertView.setTag(holder);
        }
        else //exist view
        {
            holder=(Tuan6ViewHolder) convertView.getTag();
        }
        //set data for view
        Tuan6Product product=mList.get(position);
        if(product!=null){
            Picasso.get().load(product.getSearchImage())
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(holder.searchImage);
            holder.tvStyleId.setText(product.getStyleId());
            holder.tvPrice.setText(product.getPrice());
            holder.tvBrand.setText(product.getBrand());
            holder.tvAddictionalInfo.setText(product.getAdditionalInfo());
        }
        //xu ly su kien
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tuan6Product product=mList.get(position);//lay ve doi tuong da chon
                Intent intent=new Intent(mContext,Tuan6DetailActivity.class);
                intent.putExtra("PRODUCT",product);//dong goi product
                mContext.startActivity(intent);//van chuyen product sang detail
            }
        });
        return convertView;
    }
    static class Tuan6ViewHolder{//refer to item_view
        ImageView searchImage;
        TextView tvStyleId,tvBrand,tvPrice,tvAddictionalInfo;
    }
}
