package com.example.myapplication.sp34;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SP34Adapter extends BaseAdapter {
    private Context mContext;
    private List<SP34Product> mList;

    public SP34Adapter(Context mContext, List<SP34Product> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //create view
    //set data for view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. Create view
        SP34ViewHolder holder;
        if(convertView==null)//tao view moi neu chua co view
        {
            //sinh blank layout
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.item_view_sp34,parent,false);
            //anh xa cac truong tu viewholder vao layout
            holder=new SP34ViewHolder();
            holder.img=convertView.findViewById(R.id.sp34_itemview_img);
            holder.tvBrand=convertView.findViewById(R.id.sp34_itemview_brand);
            holder.tvStyleId=convertView.findViewById(R.id.sp34_itemview_styleid);
            holder.tvAdditionInfo=convertView.findViewById(R.id.sp34_itemview_addictionalInfo);
            holder.tvPrice=convertView.findViewById(R.id.sp34_itemview_price);
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else {
            holder=(SP34ViewHolder) convertView.getTag();//lay view cu
        }
        //2. gan du lieu cho view
        SP34Product product=mList.get(position);
        if(product!=null){
            Picasso.get().load(product.getSearchImage())
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(holder.img);
            holder.tvPrice.setText(product.getPrice());
            holder.tvBrand.setText(product.getBrand());
            holder.tvStyleId.setText(product.getStyleId());
            holder.tvAdditionInfo.setText(product.getAddictionalInfo());
        }
        return convertView;
    }

    static class SP34ViewHolder{
        ImageView img;
        TextView tvStyleId,tvBrand,tvPrice,tvAdditionInfo;
    }
}
