package com.example.myapplication.sp34;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SP34MainActivity extends AppCompatActivity {
    private ListView listView;
    private SP34Adapter adapter;
    private List<SP34Product> list=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp34_main);
        listView=findViewById(R.id.sp34Listview);
        adapter=new SP34Adapter(this,list);
        listView.setAdapter(adapter);
        //viet ham doc du lieu tu server
        new FetchDataTask().execute();
    }
    private class FetchDataTask extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            //tao box luu du lieu
            StringBuilder response=new StringBuilder();
            try {
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");//url
                //mo ket noi
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //xac dinh phuong thuc doc du lieu
                connection.setRequestMethod("GET");
                //tao bo dem doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc tung dong
                String line="";
                while ((line=reader.readLine())!=null){//doc tung dong cho den het
                    response.append(line);//dua dong doc duoc vao ket qua
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //return result to client
        @Override
        protected void onPostExecute(String s) {
            if(s!=null && !s.isEmpty()){
                try {
                    //chuyen du lieu sang json
                    JSONObject json=new JSONObject(s);
                    //lay ve mang cua cac doi tuong
                    JSONArray pArray=new JSONArray("products");
                    //doc tung doi tuong qua vong for
                    for(int i=0;i<pArray.length();i++){
                        //lay ve doi tuong
                        JSONObject pObj=pArray.getJSONObject(i);
                        //lay ve tung truong cua doi tuong
                        String styleid=pObj.getString("styleid");
                        String brand=pObj.getString("brands_filter_facet");
                        String price=pObj.getString("price");
                        String addictionalInfo=pObj.getString("product_additional_info");
                        String searchImage=pObj.getString("search_image");
                        //tao doi tuong voi cac thong tin da doc
                        SP34Product product=new SP34Product(styleid,brand,price,addictionalInfo,searchImage);
                        //them doi tuong vao list
                        list.add(product);
                    }
                    adapter.notifyDataSetChanged();//cap nhat lai adapter
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }

            }
        }
    }
}