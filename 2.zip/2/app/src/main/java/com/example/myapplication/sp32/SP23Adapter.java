package com.example.myapplication.sp32;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SP23Adapter extends BaseAdapter {
    private Context context;
    private List<SP32Product> list;

    public SP23Adapter(Context context, List<SP32Product> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1tao view
        SP32ViewHolder holder;
        if(convertView==null)//neu chua co view thi tao view moi
        {
            //1.1 tao view trang
            convertView= LayoutInflater.from(context).inflate(R.layout.sp32_item_view,parent,false);
            //1.2 anh xa voi viewholder
            holder=new SP32ViewHolder();
            holder.img=convertView.findViewById(R.id.sp2_itemview_searchimage);
            holder.tvAddinfo=convertView.findViewById(R.id.sp2_itemview_addinfo);
            holder.tvBrand=convertView.findViewById(R.id.sp2_itemview_brand);
            holder.tvPrice=convertView.findViewById(R.id.sp2_itemview_price);
            holder.tvStyleid=convertView.findViewById(R.id.sp2_itemview_styleid);
            //1.3 tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else //neu da co view thi lay view cu
        {
            holder=(SP32ViewHolder) convertView.getTag();
        }
        //2.gan du lieu cho view
        SP32Product product=list.get(position);
        if(product!=null){
            Picasso.get().load(product.getSearchImage())
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(holder.img);
            holder.tvStyleid.setText(product.getStyleId());
            holder.tvBrand.setText(product.getBrand());
            holder.tvPrice.setText(product.getPrice());
            holder.tvAddinfo.setText(product.getAddInfo());
        }
        return convertView;
    }

    static class SP32ViewHolder {
        ImageView img;
        TextView tvStyleid,tvBrand,tvPrice,tvAddinfo;
    }
}
