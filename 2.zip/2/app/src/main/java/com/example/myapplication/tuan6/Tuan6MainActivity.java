package com.example.myapplication.tuan6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Tuan6MainActivity extends AppCompatActivity {
    ListView listView;
    private List<Tuan6Product> list;
    private Tuan6Adapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuan6_main);
        listView=findViewById(R.id.tuan6Listview);
        list=new ArrayList<>();
        adapter=new Tuan6Adapter(this,list);
        listView.setAdapter(adapter);
        //get data from server
        new FetchProductTask().execute();
    }
    private class FetchProductTask extends AsyncTask<Void,Void,String>{
        //get data from server
        @Override
        protected String doInBackground(Void... voids) {
            //create box for archive data
            StringBuilder response=new StringBuilder();
            try {
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //create buffer
                BufferedReader reader=new
                        BufferedReader(new InputStreamReader(connection.getInputStream()));
                //read by line
                String line="";
                while ((line=reader.readLine())!=null){
                    response.append(line);
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //return data to client
        @Override
        protected void onPostExecute(String s) {
            if(s!=null && !s.isEmpty()){
                try {
                    //convert result to json
                    JSONObject json=new JSONObject(s);
                    JSONArray pArray=json.getJSONArray("products");
                    for(int i=0;i<pArray.length();i++){
                        JSONObject pObj=pArray.getJSONObject(i);
                        String styleId=pObj.getString("styleid");
                        String brand=pObj.getString("brands_filter_facet");
                        String price=pObj.getString("price");
                        String additionalInfo=pObj.getString("product_additional_info");
                        String searchImage=pObj.getString("search_image");
                        Tuan6Product p=new Tuan6Product(styleId,brand,price,additionalInfo,searchImage);
                        list.add(p);//add product to list
                    }
                    //update data to the adapter
                    adapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}