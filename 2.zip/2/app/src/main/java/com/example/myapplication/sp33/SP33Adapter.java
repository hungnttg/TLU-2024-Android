package com.example.myapplication.sp33;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SP33Adapter extends BaseAdapter {
    private Context mContext;
    private List<SP33Product> mList;

    public SP33Adapter(Context mContext, List<SP33Product> mList) {
        this.mContext = mContext;
        this.mList = mList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //Tao view
    //Thiet lap du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. tao view
        SP33ViewHolder holder;
        if(convertView==null){//neu chua ton tai -> tao view moi
            //1.1 tao blank layout
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.item_view_sp33,parent,false);
            //1.2. gan voi viewHolder
            holder=new SP33ViewHolder();
            //1.3 Anh xa tung thanh phan
            holder.img=convertView.findViewById(R.id.sp33_itemview_img);
            holder.tvBrand=convertView.findViewById(R.id.sp33_itemview_brand);
            holder.tvStyleid=convertView.findViewById(R.id.sp33_itemview_styleid);
            holder.tvPrice=convertView.findViewById(R.id.sp33_itemview_price);
            holder.tvAddInfo=convertView.findViewById(R.id.sp33_itemview_addinfo);
            //1.4. tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else//neu da ton tai -> lay view cu
        {
            holder=(SP33ViewHolder) convertView.getTag();
        }
        //2. thiet lap du lieu
        SP33Product product=mList.get(position);
        if(product!=null){
            Picasso.get().load(product.getSearchImage())
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(holder.img);
            holder.tvAddInfo.setText(product.getAddInfo());
            holder.tvPrice.setText(product.getPrice());
            holder.tvBrand.setText(product.getBrand());
            holder.tvStyleid.setText(product.getStyleId());
        }
        return convertView;
    }

    static class SP33ViewHolder {
        ImageView img;
        TextView tvStyleid,tvBrand,tvPrice, tvAddInfo;
    }
}
