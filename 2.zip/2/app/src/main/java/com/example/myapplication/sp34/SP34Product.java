package com.example.myapplication.sp34;

public class SP34Product {
    private String styleId;
    private String brand;
    private String price;
    private String addictionalInfo;
    private String searchImage;

    public SP34Product() {
    }

    public SP34Product(String styleId, String brand, String price, String addictionalInfo, String searchImage) {
        this.styleId = styleId;
        this.brand = brand;
        this.price = price;
        this.addictionalInfo = addictionalInfo;
        this.searchImage = searchImage;
    }

    public String getStyleId() {
        return styleId;
    }

    public void setStyleId(String styleId) {
        this.styleId = styleId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAddictionalInfo() {
        return addictionalInfo;
    }

    public void setAddictionalInfo(String addictionalInfo) {
        this.addictionalInfo = addictionalInfo;
    }

    public String getSearchImage() {
        return searchImage;
    }

    public void setSearchImage(String searchImage) {
        this.searchImage = searchImage;
    }
}
