package com.example.myapplication.sp32;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SP32MainActivity extends AppCompatActivity {
    private ListView listView;
    private List<SP32Product> list=new ArrayList<>();
    private SP23Adapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp32_main);
        listView=findViewById(R.id.sp32Lv);
        adapter=new SP23Adapter(this,list);
        listView.setAdapter(adapter);

        new FetchDataTask().execute();
    }
    class FetchDataTask extends AsyncTask<Void,Void,String>{
        //doc ket qua tu server
        @Override
        protected String doInBackground(Void... voids) {
            //khai bao box chua ket qua
            StringBuilder response=new StringBuilder();
            try {
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");//chon phuong thuc doc du lieu
                //tao bo dem doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //doc du lieu theo dong
                String line="";
                while ((line=reader.readLine())!=null){//doc theo dong
                    response.append(line);//dua dong doc duoc vao ket qua
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();
        }
        //tra ket qua cho client
        @Override
        protected void onPostExecute(String s) {
            if(s!=null && !s.isEmpty()){
                try {
                    JSONObject json=new JSONObject(s);//lay ve doi tuong json
                    JSONArray pArray=json.getJSONArray("products");//lay ve mang products
                    for (int i=0;i<pArray.length();i++){
                        JSONObject pObj=pArray.getJSONObject(i);//lay ve tung doi tuong
                        //lay ve tung truong cua doi tuong
                        String image=pObj.getString("search_image");
                        String styleid=pObj.getString("styleid");
                        String brand=pObj.getString("brands_filter_facet");
                        String price=pObj.getString("price");
                        String addInfo=pObj.getString("product_additional_info");
                        //tao 1 doi tuong voi cac truong du lieu vua lay duoc
                        SP32Product product=new SP32Product(image,styleid,brand,price,addInfo);
                        //them vao list
                        list.add(product);
                    }
                    //load lai adapter
                    adapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}