package com.example.myapplication.t61;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;
import com.example.myapplication.R;

public class CartAdapter extends ArrayAdapter<Product> {
    private Context mContext;

    public CartAdapter(Context context, List<Product> products) {
        super(context, 0, products);
        mContext = context;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView,
                        @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null) {
            listItem = LayoutInflater.from(mContext)
                    .inflate(R.layout.cart_item, parent, false);
        }

        // Lấy sản phẩm hiện tại
        Product currentProduct = getItem(position);

        // Hiển thị thông tin sản phẩm trong danh sách giỏ hàng
        TextView productName = listItem
                .findViewById(R.id.textViewProductName);
        productName.setText(currentProduct.getStyleId());

        // Hiển thị số lượng và giá của sản phẩm
        TextView productQuantity =
                listItem.findViewById(R.id.textViewProductQuantity);
        productQuantity.setText("Quantity: " + 1);
        // Xử lý sự kiện khi người dùng thay đổi số lượng sản phẩm
        return listItem;
    }
}
