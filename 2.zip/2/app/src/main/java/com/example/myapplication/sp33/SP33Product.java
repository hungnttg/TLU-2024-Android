package com.example.myapplication.sp33;

public class SP33Product {
    private String searchImage;
    private String styleId;
    private String brand;
    private String price;
    private String addInfo;

    public SP33Product() {
    }

    public SP33Product(String searchImage, String styleId, String brand, String price, String addInfo) {
        this.searchImage = searchImage;
        this.styleId = styleId;
        this.brand = brand;
        this.price = price;
        this.addInfo = addInfo;
    }

    public String getSearchImage() {
        return searchImage;
    }

    public void setSearchImage(String searchImage) {
        this.searchImage = searchImage;
    }

    public String getStyleId() {
        return styleId;
    }

    public void setStyleId(String styleId) {
        this.styleId = styleId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAddInfo() {
        return addInfo;
    }

    public void setAddInfo(String addInfo) {
        this.addInfo = addInfo;
    }
}
